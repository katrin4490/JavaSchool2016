import React, { Component } from 'react';

class App extends Component{
    constructor (props){
        super(props);

    }


    render(){
        return (
         <div>
           {this.props.children}
           <div> hi {this.props.target}</div>
         </div>
        );
    }
}

App.propTypes = {
    target: React.PropTypes.string.isRequired
};

export default App;