import React from 'react';
import ReactDOM from 'react-dom';
import App from './components/App';

ReactDOM.render(
    <App target="JAVA">Hello1111</App>,
    document.getElementById('app')
);