package ru.sbrf.course;

import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;

/**
 * Created by Student on 04.08.2016.
 */
public class CalculatorUTest {
    Calculator calculator;
    @Before
    public void init(){
        calculator = new Calculator();
    }

    @Test
    public void addTest(){
        Assert.assertTrue("Неверное сложение", calculator.add(2, 5) == 5);
    }
}
