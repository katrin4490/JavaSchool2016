package ru.sbrf.course.buildtools.core;

public class ControllerTest {

}
