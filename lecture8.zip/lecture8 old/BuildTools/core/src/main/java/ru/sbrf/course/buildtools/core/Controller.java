package ru.sbrf.course.buildtools.core;

//import org.slf4j;
public class Controller {

}
