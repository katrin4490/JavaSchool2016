package ru.sbrf.course.buildtools.core;

import org.slf4j.Logger;

public class Controller {
}
