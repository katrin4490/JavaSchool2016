package ru.sbrf.course;

public interface SlowTests {
}
