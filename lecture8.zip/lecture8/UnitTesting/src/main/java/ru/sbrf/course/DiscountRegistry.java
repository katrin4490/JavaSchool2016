package ru.sbrf.course;

public interface DiscountRegistry {

    int getDiscount(Item item);

}
